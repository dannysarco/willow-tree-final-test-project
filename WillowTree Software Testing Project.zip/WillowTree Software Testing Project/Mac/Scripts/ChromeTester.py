from selenium import webdriver
from selenium.webdriver.common.by import By
import time

cdriver = WebDriver = webdriver.Chrome(executable_path="/Users/danielsarco/Drivers/chromedriver")
cdriver.get("http://www.ericrochester.com/name-game/")

print("<title>", cdriver.title)
print("Page name is", cdriver.name)
print("URL is", cdriver.current_url)


def click_all():
    time.sleep(4)

    print("<tr>", file=open("chrome.html", "a"))
    print("<td>", count + 1, "</td>", file=open("chrome.html", "a"))
    matchname = cdriver.find_element(By.XPATH, "//span[contains(.,\'\')]")  # name to match too (control picture)
    print("<td>", matchname.get_attribute('innerHTML'), "</td>", file=open("chrome.html", "a"))
    time.sleep(.3)

    pic1name = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(1) > .name").get_attribute('innerHTML')
    print("<td>", pic1name, "</td>", file=open("chrome.html", "a"))
    pic1 = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(1) > .shade").click()  # click first picture
    time.sleep(.3)

    pic2name = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(2) > .name").get_attribute('innerHTML')
    print("<td>", pic2name, "</td>", file=open("chrome.html", "a"))
    pic2 = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(2) > .shade").click()  # click second picture
    time.sleep(.3)

    pic3name = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(3) > .name").get_attribute('innerHTML')
    print("<td>", pic3name, "</td>", file=open("chrome.html", "a"))
    pic3 = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(3) > .shade").click()  # click third picture
    time.sleep(.3)

    pic4name = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(4) > .name").get_attribute('innerHTML')
    print("<td>", pic4name, "</td>", file=open("chrome.html", "a"))
    pic4 = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(4) > .shade").click()  # click fourth picture
    time.sleep(.3)

    pic5name = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(5) > .name").get_attribute('innerHTML')
    print("<td>", pic5name, "</td>", file=open("chrome.html", "a"))
    pic5 = cdriver.find_element(By.CSS_SELECTOR, ".photo:nth-child(5) > .shade").click()  # click fifth picture
    time.sleep(.3)

    correctpicname = cdriver.find_element(By.CSS_SELECTOR, ".correct > .name")
    print("<td>", correctpicname.get_attribute('innerHTML'), "</td>", file=open("chrome.html", "a"))

    element = cdriver.find_element(By.XPATH, "//div[@id=\'stats\']/span")

    print("</tr>", file=open("chrome.html", "a"))


count = 0
while count < 15:
    print(click_all())
    count += 1

print("</tbody>", file=open("chrome.html", "a"))
print("</table>", file=open("chrome.html", "a"))
print("<p> </p>", file=open("chrome.html", "a"))
print("<table class=\"tstats\">", file=open("chrome.html", "a"))
print("<thead>", file=open("chrome.html", "a"))
print("<tr>", file=open("chrome.html", "a"))
print("<th>Iterations</th>", file=open("chrome.html", "a"))
print("<th>Clicks Per Iteration</th>", file=open("chrome.html", "a"))
print("<th>Calculated Clicks</th>", file=open("chrome.html", "a"))
print("<th>Counted Clicks</th>", file=open("chrome.html", "a"))
print("<th>Expected Clicks = Actual Clicks?</th>", file=open("chrome.html", "a"))
print("<th>Expected Number of Trys?</th>", file=open("chrome.html", "a"))
print("<th>Temp5</th>", file=open("chrome.html", "a"))
print("<th>Temp6</th>", file=open("chrome.html", "a"))
print("</tr>", file=open("chrome.html", "a"))
print("</thead>", file=open("chrome.html", "a"))
print("<tbody>", file=open("chrome.html", "a"))
print("<tr>", file=open("chrome.html", "a"))
a = int(count * 5)  # calculated clicks/trys (iterations * number of clicks per round)
b = int(cdriver.find_element(By.XPATH, "//div[3]/span").get_attribute('innerHTML'))  # actual clicks/trys (stored value)
print("<td>", count, "</td>", file=open("chrome.html", "a"))
print("<td>", 5, "</td>", file=open("chrome.html", "a"))
# the above number is based of off each picture being programmatically clicked once per round
print("<td>", a, "</td>", file=open("chrome.html", "a"))
print("<td>", b, "</td>", file=open("chrome.html", "a"))
if a != b:
    print("<td>", "No", "</td>", file=open("chrome.html", "a"))
elif a == b:
    print("<td>", "Yes", "</td>", file=open("chrome.html", "a"))
if a == b:
    print("<td>", "Yes", "</td>", file=open("chrome.html", "a"))
elif a != b:
    print("<td>", "No", "</td>", file=open("chrome.html", "a"))
print("<td>", count, "</td>", file=open("chrome.html", "a"))
print("<td>", count, "</td>", file=open("chrome.html", "a"))
print("</tr>", file=open("chrome.html", "a"))
print("</tbody>", file=open("chrome.html", "a"))
print("</table>", file=open("chrome.html", "a"))
print("<div class=\"more_space\"> </div>", file=open("chrome.html", "a"))
print("</body>", file=open("chrome.html", "a"))
print("</html>", file=open("chrome.html", "a"))

cdriver.quit()
